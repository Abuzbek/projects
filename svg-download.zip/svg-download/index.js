// const http = require('http')
// http.createServer((req,res)=>{
//   res.sendFile()
//   res.end()
// }).listen(3000, console.log('http://localhost:3000'))
const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const fs = require("fs");
const app = express();
const cors = require("cors");
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json({ limit: "500mb" }));
app.get("/", (req, res) => {
  res.write("hello");
  res.end();
});
let file = ''
let d = new Date()
app.post("/", async (req, res) => {
  console.log(req.body.files);
  await req.body.files.forEach(e =>{
    fs.writeFile(
      path.join(__dirname, "img", `${Date.now()}.svg`),
      `<svg xmlns="http://www.w3.org/2000/svg"><image href="${e}" width="300" height="300" /></svg>`,
      "utf-8",
      (err) => {
        if (err) console.log(err);
        console.log("papka yaratdik");
      }
    );
  })
  // await req.body.name.forEach((element) => {
  //   fs.writeFile(
  //     path.join(__dirname, "img", `${element}.svg`),
  //     `<svg xmlns="http://www.w3.org/2000/svg"><image href="${file}" /></svg>`,
  //     "utf-8",
  //     (err) => {
  //       if (err) console.log(err);
  //       console.log("papka yaratdik");
  //     }
  //   );
  // });
  res.redirect("/");
});
app.listen(3000, () => {
  console.log("http://localhost:3000");
});
