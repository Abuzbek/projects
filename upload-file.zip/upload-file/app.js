import { upload } from './upload.js'
import 'firebase/storage'
import firebase from 'firebase/app'

const  firebaseConfig = {
  apiKey: "AIzaSyDgphLsZbdRM61J_IBpoQsboWYhT9AYR_M",
  authDomain: "fe-upload-js.firebaseapp.com",
  projectId: "fe-upload-js",
  storageBucket: "fe-upload-js.appspot.com",
  messagingSenderId: "687084870210",
  appId: "1:687084870210:web:d088b45c132780cba02bdb"
}
firebase.initializeApp(firebaseConfig);

const storage = firebase.storage()
console.log(storage);


upload('#file', {
  multi:true,
  accept: ['.png', '.jpg', '.jpeg', '.gif'],
  onUpload(file, blocks){
    file.forEach((element,i) => {
      const ref = storage.ref(`images/${element.name}`)
      const task = ref.put(element)
      task.on('state_changed', snapshot =>{
        const pratsentage = ((snapshot.bytesTransferred / snapshot.totalBytes) * 100).toFixed(0)
        const block = blocks[i].querySelector('.preview-info-progress');
        block.textContent = `${pratsentage}%` 
        block.style.width = `${pratsentage}%`
      }, error =>{
        console.log(error);
      },()=>{
        console.log('completed');
      })
    });
  }
})
console.log('app.js');