import React, { useReducer } from "react";
import axios from "axios";
import FirebaseContext from "./firebase.context";
import FirebaseReducer from "./firebase.reducer";
import { ADD_NOTE, FETCH_NOTES, REMOVE_NOTES, SHOW_LOADER } from "../types";
const url = process.env.REACT_APP_DB_URL;
const FirebaseState = ({ children }) => {
  const initialState = {
    notes: [],
    loading: false,
  };
  const [state, dispatch] = useReducer(FirebaseReducer, initialState);
  const showLoader = () => dispatch({ type: SHOW_LOADER });
  const fetchNotes = async () => {
    try {
      showLoader();
      const res = await axios.get(`${url}/notes.json`);
      const payload = Object.keys(res.data).map((key) => {
        return {
          ...res.data[key],
          id: key,
        };
      });
      dispatch({
        type: FETCH_NOTES,
        payload,
      });
    } catch (error) {}
  };
  const AddNote = async (title) => {
    const todo = {
      title,
      data: new Date().toJSON(),
    };
    try {
      const res = await axios.post(`${url}/notes.json`, todo);
      const payload = {
        ...todo,
        id: res.data.name,
      };
      dispatch({
        type: ADD_NOTE,
        payload,
      });
    } catch (error) {
      throw new Error(error.message);
    }
  };
  const removeNotes = async (id) => {
    const res = await axios.delete(`${url}/notes/${id}.json`);
    dispatch({
      type: REMOVE_NOTES,
      payload: id,
    });
    console.log(res.data);
  };
  return (
    <FirebaseContext.Provider
      value={{
        showLoader,
        fetchNotes,
        AddNote,
        removeNotes,
        loading: state.loading,
        notes: state.notes,
      }}
    >
      {children}
    </FirebaseContext.Provider>
  );
};
export default FirebaseState;
