import React, { useContext, useEffect } from "react";
import Form from "../components/Form";
import Loader from "../components/Loader";
import Notes from "../components/Notes";
import FirebaseContext from "../context/firebase/firebase.context";

export default function Home() {
  const { fetchNotes, loading, notes, removeNotes } =
    useContext(FirebaseContext);
  useEffect(() => {
    fetchNotes();
    // eslint-disable-next-line
  }, []);
  return (
    <React.Fragment>
      <Form />
      <hr />
      {loading ? <Loader /> : <Notes onRemove={removeNotes} notes={notes} />}
    </React.Fragment>
  );
}
