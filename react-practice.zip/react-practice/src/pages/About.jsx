import React from "react";
const About = () => (
  <div className="p-5 mb-4 bg-light rounded-3 mt-4">
    <div className="container">
      <h1 className="display-4">Abuzcoder (ENG Yaxshi react dastur)</h1>
      <p className="lead">
        Dastur versiyasi <strong>1.0.43</strong>
      </p>
    </div>
  </div>
);
export default About;
