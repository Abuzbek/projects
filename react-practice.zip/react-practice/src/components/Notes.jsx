import React from "react";
import { TransitionGroup, CSSTransition } from "react-transition-group";
export default function Notes({ notes, onRemove }) {
  console.log(notes);
  return (
    <TransitionGroup component={"ul"} className="list-group">
      {notes.map((note) => (
        <CSSTransition
          key={note.id}
          classNames={"note"}
          timeout={{
            enter: 500,
            exit: 350,
          }}
          mountOnEnter
          unmountOnExit
        >
          <li className="list-group-item note">
            <div>
              <strong>{note.title}</strong>
              <small>{new Date(note.data).toLocaleString()}</small>
            </div>
            <button
              onClick={() => onRemove(note.id)}
              className="btn-close"
            ></button>
          </li>
        </CSSTransition>
      ))}
    </TransitionGroup>
  );
}
