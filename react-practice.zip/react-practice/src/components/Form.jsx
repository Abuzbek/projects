import React, { useState, useContext } from "react";
import AlertContext from "../context/action/alertContext";
import FirebaseContext from "../context/firebase/firebase.context";

const Form = () => {
  const [value, setValue] = useState("");
  const alert = useContext(AlertContext);
  const firebase = useContext(FirebaseContext);
  const submitHandler = (e) => {
    e.preventDefault();
    if (value.trim()) {
      firebase
        .AddNote(value.trim())
        .then(() => {
          alert.show("Yorliq muvaffaqiyatli yasaldi", "success");
        })
        .catch(() => {
          alert.show("bunday yubormaydilar", "danger");
        });
      setValue("");
    } else {
      alert.show("Iltimos boshliqni toldiring", "danger");
    }
  };
  return (
    <form onSubmit={submitHandler}>
      <div className="form-group">
        <input
          type="text"
          placeholder="Yorliqni nomini kiriting"
          className="form-control"
          value={value}
          onChange={(e) => setValue(e.target.value)}
        />
      </div>
    </form>
  );
};
export default Form;
