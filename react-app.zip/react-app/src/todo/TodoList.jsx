import React, { Component } from "react";
import PropTypes from "prop-types";
import TodoItem from "./TodoItem";
const styles = {
  ul: {
    listStyle: "none",
    padding:0,
    margin:0
  },
};
class TodoList extends Component {
  render() {
    const { todo,onToggle } = this.props;
    return (
      <ul style={styles.ul}>
        {todo.map((n, i) => {
          return (
            <TodoItem
              key={n.id}
              todo={n}
              index={i}
              onChanges={onToggle}
            />
          );
        })}
      </ul>
    );
  }
}
TodoList.propTypes = {
  todo: PropTypes.arrayOf(PropTypes.object).isRequired,
  onToggle: PropTypes.func.isRequired,
};
export default TodoList;
