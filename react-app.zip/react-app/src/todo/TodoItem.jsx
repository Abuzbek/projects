import React, {  useContext } from "react";
import PropTypes from "prop-types";
import Context from '../context'
function TodoItem(props)  {
    const {removeTodo} = useContext(Context)
    const style = {
      li: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: ".5rem 1rem",
        border: "1px solid #ccc",
        borderRadius: "4px",
        marginBottom: ".5rem",
      },
      checkbox: {
        marginRight: "1rem",
      },
      rm: {
        background: "red",
        borderRadius: "50%",
        border: "none",
        color: "#fff",
      },

    };
    const { todo, index, onChanges } = props;
    return (
      <li style={style.li}>
        <span className={todo.completed ? 'done' : ''}>
          <input
            type="checkbox"
            style={style.checkbox}
            onChange={()=>onChanges(todo.id)}
            checked={todo.completed}
          />
          <b>{index + 1}</b>
          &nbsp;
            {todo.title}
        </span>
        <button onClick={()=>removeTodo(todo.id)} style={style.rm}>&times;</button>
      </li>
    );
}

TodoItem.propTypes = {
  todo: PropTypes.object.isRequired,
  index: PropTypes.number,
  onChanges:PropTypes.func
};

export default TodoItem;
