import { chart } from "./chart";
import { getChartData } from "./data";
import "./style.scss";

const canvas = document.getElementById("chart");
const tgChart = chart(canvas, getChartData());
tgChart.init();
