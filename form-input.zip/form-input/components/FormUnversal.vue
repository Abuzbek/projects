<template>
  <form @submit.prevent="submitHandler(data)">
    <div v-for="(value, key) in data" :key="key">
      <input type="text" id="" v-model="data[key]" />
    </div>
    <button type="submit">click</button>
    <pre>
      {{ data }}
    </pre>
  </form>
</template>

<script>
export default {
  data: () => ({
    obj: {
      name: "hello",
      sur: "shed"
    }
  }),
  props: ["data", "submitHandler"],
};
</script>
