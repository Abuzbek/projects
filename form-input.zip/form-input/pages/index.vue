<template>
  <form-unversal :data="data" :submitHandler='submitHandler' />
</template>

<script>
import FormUnversal from "../components/FormUnversal.vue";
export default {
  components: { FormUnversal },
  data:()=>({
    data:{
      name: '',
      email: ''
    }
  }),
  methods:{
    submitHandler(data){
      console.log(data);
    }
  }

};
</script>
