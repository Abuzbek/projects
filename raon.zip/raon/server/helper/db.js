module.exports = {
  db: 'mongodb+srv://KoreaRaon:yshub2020@cluster0.jtu4m.mongodb.net/test'
}