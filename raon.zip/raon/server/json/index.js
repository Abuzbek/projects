module.exports = [
  {
    _id:'234df4fg5g56h6hj66h',
    name: 'Terapic Premium Total Hair Tonic.',
    img: 'https://i.ibb.co/bmwxvH6/Lacafone-Toner-Pad-Poduim.jpg',
    clicked: false,
    price: 1500
  },
  {
    _id:'278rf478fh8924uf8j',
    name: 'Terapic Premium Total Hair Tonic.',
    img: 'https://i.ibb.co/09wTFJ5/Pobam-Serum-Podium.jpg',
    sale:1000,
    clicked: false,
    price: 1500
  },
  {
    img:'https://i.ibb.co/mFJw3XT/Itammy-Podium.jpg',
    _id:'sdfvw43ff353g35g5g',
    name:'ITAMMY moisturizing mist pack.',
    sale:1000,
    clicked: false,
    price: 1500
  },
  {
    img:'https://i.ibb.co/5vRcQD5/Pobam-Moonlight-Pore-Clean-mask.jpg',
    _id:'g4h67jh5h4g3f234d23',
    name:'POBAM Moonlight Cream',
    sale:1000,
    clicked: false,
    price: 1500
  },
  {
    img:'https://i.ibb.co/T2p8VjC/Pobam-Toner-Pads.jpg',
    _id:'232df2f53h56h5j67j8k',
    name:'Moonlight Toner Pads',
    sale:1000,
    clicked: false,
    price: 1500
  },
  {
    img:'https://i.ibb.co/4sYKsBL/Turn-up-waxing-scaled.jpg',
    _id:'87k784eg43f547uj67k8',
    name:'Turn up Waxing',
    sale:1000,
    clicked: false,
    price: 1500
  },
  {
    img:'https://i.ibb.co/g9px4q5/Premium-Total-Hair-Tonic-Podium.jpg',
    _id:'67j673tgg53gh5h6u77u',
    name:'Terapic Premium Total Hair Tonic.',
    sale:1000,
    clicked: false,
    price: 1500            
  }
]