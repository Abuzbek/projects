<template>
  <nuxt-link :to="href" class="edvestCard">
      <img :src="img" alt="" class="edvest_img">
      <div class="edvest_title">
        {{ title }}
      </div>
  </nuxt-link>
</template>
<script>
export default {
  props:{
    img:{
      type:String,
      required:true
    },
    href:{
      type:String,
      required:true
    },
    title:{
      type:String,
      required:true
    }
  }
}
</script>
<style lang="scss" scoped>
.edvestCard{
  text-decoration: none;
  img{
    width:100%;
    height:auto;
    object-fit: cover;
  }
  .edvest_title{
    font-weight: 500;
    font-size: 16px;
    line-height: 150%;
    color: #3E4549;
    text-decoration: none;
  }
}
</style>