export default [
  {
    img: "https://i.ibb.co/3vKyDPW/caraousel.jpg",
    href: "#!"
  },
  {
    img: "https://i.ibb.co/3vKyDPW/caraousel.jpg",
    href: "#!"
  },
  {
    img: "https://i.ibb.co/3vKyDPW/caraousel.jpg",
    href: "#!"
  }
];
