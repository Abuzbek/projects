export default [
  {
    _id:'ajnsd872u2if24f398',
    img:'https://i.ibb.co/3fRC4P8/photo.jpg',
    heading:'Уродина, в поисках пути к счастью и процветанию',
    paper:true,
    ebook:true,
    audio:true,
    author:'Скотт Вестерфельд',
    news:true,
    best:true,
    price:240.000,
    sale:140.000,
  },
  {
    _id:'akjf4893fj3849f3fg',
    img:'https://i.ibb.co/3fRC4P8/photo.jpg',
    heading:'Уродина, в поисках пути к счастью и процветанию',
    paper:true,
    ebook:true,
    audio:true,
    author:'Скотт Вестерфельд',
    news:true,
    best:false,
    price:260.000,
    sale:170.000,
  },

]