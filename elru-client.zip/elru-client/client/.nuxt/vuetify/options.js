export default {"theme":{"dark":false,"themes":{"dark":{"defaults":"#01BEDE","grey":"#616D75"}}}}
