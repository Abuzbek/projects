export { default as Card } from '../..\\components\\card.vue'
export { default as NavbarBottom } from '../..\\components\\navbarBottom.vue'
export { default as NavbarTop } from '../..\\components\\navbarTop.vue'
export { default as NavbarTopItems } from '../..\\components\\navbarTopItems.vue'
export { default as NavTopLang } from '../..\\components\\navTopLang.vue'
export { default as NavTopPhone } from '../..\\components\\navTopPhone.vue'
export { default as CardEdvest } from '../..\\components\\cards\\cardEdvest.vue'
export { default as IndexCarousel } from '../..\\components\\partials\\indexCarousel.vue'
export { default as IndexEdvest } from '../..\\components\\partials\\indexEdvest.vue'
export { default as SliderEdvest } from '../..\\components\\sections\\sliderEdvest.vue'
export { default as Sliders } from '../..\\components\\sections\\Sliders.vue'
export { default as SidebarXl } from '../..\\components\\sidebar\\sidebar_xl.vue'
export { default as NavbarBasketLink } from '../..\\components\\navbar_bottom\\navbarBasketLink.vue'
export { default as NavbarChatLink } from '../..\\components\\navbar_bottom\\navbarChatLink.vue'
export { default as NavbarMenuLayout } from '../..\\components\\navbar_bottom\\navbarMenuLayout.vue'
export { default as NavbarSaveLink } from '../..\\components\\navbar_bottom\\navbarSaveLink.vue'
export { default as NavbarSearchInput } from '../..\\components\\navbar_bottom\\navbarSearchInput.vue'
export { default as UserProfilLink } from '../..\\components\\navbar_bottom\\userProfilLink.vue'

export const LazyCard = import('../..\\components\\card.vue' /* webpackChunkName: "components/card" */).then(c => c.default || c)
export const LazyNavbarBottom = import('../..\\components\\navbarBottom.vue' /* webpackChunkName: "components/navbar-bottom" */).then(c => c.default || c)
export const LazyNavbarTop = import('../..\\components\\navbarTop.vue' /* webpackChunkName: "components/navbar-top" */).then(c => c.default || c)
export const LazyNavbarTopItems = import('../..\\components\\navbarTopItems.vue' /* webpackChunkName: "components/navbar-top-items" */).then(c => c.default || c)
export const LazyNavTopLang = import('../..\\components\\navTopLang.vue' /* webpackChunkName: "components/nav-top-lang" */).then(c => c.default || c)
export const LazyNavTopPhone = import('../..\\components\\navTopPhone.vue' /* webpackChunkName: "components/nav-top-phone" */).then(c => c.default || c)
export const LazyCardEdvest = import('../..\\components\\cards\\cardEdvest.vue' /* webpackChunkName: "components/card-edvest" */).then(c => c.default || c)
export const LazyIndexCarousel = import('../..\\components\\partials\\indexCarousel.vue' /* webpackChunkName: "components/index-carousel" */).then(c => c.default || c)
export const LazyIndexEdvest = import('../..\\components\\partials\\indexEdvest.vue' /* webpackChunkName: "components/index-edvest" */).then(c => c.default || c)
export const LazySliderEdvest = import('../..\\components\\sections\\sliderEdvest.vue' /* webpackChunkName: "components/slider-edvest" */).then(c => c.default || c)
export const LazySliders = import('../..\\components\\sections\\Sliders.vue' /* webpackChunkName: "components/sliders" */).then(c => c.default || c)
export const LazySidebarXl = import('../..\\components\\sidebar\\sidebar_xl.vue' /* webpackChunkName: "components/sidebar-xl" */).then(c => c.default || c)
export const LazyNavbarBasketLink = import('../..\\components\\navbar_bottom\\navbarBasketLink.vue' /* webpackChunkName: "components/navbar-basket-link" */).then(c => c.default || c)
export const LazyNavbarChatLink = import('../..\\components\\navbar_bottom\\navbarChatLink.vue' /* webpackChunkName: "components/navbar-chat-link" */).then(c => c.default || c)
export const LazyNavbarMenuLayout = import('../..\\components\\navbar_bottom\\navbarMenuLayout.vue' /* webpackChunkName: "components/navbar-menu-layout" */).then(c => c.default || c)
export const LazyNavbarSaveLink = import('../..\\components\\navbar_bottom\\navbarSaveLink.vue' /* webpackChunkName: "components/navbar-save-link" */).then(c => c.default || c)
export const LazyNavbarSearchInput = import('../..\\components\\navbar_bottom\\navbarSearchInput.vue' /* webpackChunkName: "components/navbar-search-input" */).then(c => c.default || c)
export const LazyUserProfilLink = import('../..\\components\\navbar_bottom\\userProfilLink.vue' /* webpackChunkName: "components/user-profil-link" */).then(c => c.default || c)
