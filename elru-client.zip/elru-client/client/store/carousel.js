import carousel from '../static/carousel.js'
export const state = ()=>({
  carousel:[]
})
export const mutations  = {
  setCarousel(state, carousel){
    state.carousel = carousel
  }
}
export const actions = {
  fetch({commit}){
    commit('setCarousel', carousel)
  }
}
export const getters = {
  carousel: s => s.carousel
}