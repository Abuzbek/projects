import cards from '../static/index.js'
export const state = ()=>({
  cards:[]
})
export const mutations  = {
  setCards(state, cards){
    state.cards = [...cards,...cards,...cards,...cards]
  }
}
export const actions = {
  fetch({commit}){
    commit('setCards', cards)
  }
}
export const getters = {
  cards: s => s.cards
}