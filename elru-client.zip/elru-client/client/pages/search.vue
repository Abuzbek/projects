<template>
  <div>
    <div class="loader" v-if="loading">
      <v-progress-circular
        :size="100"
        color="primary"
        indeterminate
      ></v-progress-circular>
    </div>
    <div v-else>{{search}}</div>
  </div>
</template>
<script>
export default {
  data:()=>({
    loading:true
  }),
  computed:{
    search(){
      return this.$route.query.search.split('_').join(' ')
    }
  },
  mounted(){
    setTimeout(()=>{
      this.loading = false
    },1000)
  }
}
</script>
<style lang="scss" scoped>
.loader{
  width: 100%;
  height: 70vh;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
