<template>
  <div>
    <canvas ref="canvas" class="canvas"></canvas>
  </div>
</template>

<script>
export default {
  props:{
    L:{
      type:Number
    }
  },
  mounted() {
    const canvas = this.$refs.canvas
    let ctx = canvas.getContext("2d");
    let h = (canvas.height = 1000);
    let w = (canvas.width = 700);
    ctx.translate(w / 2, 0);
    let thisis = this

    let initPhi = Math.PI * 0.2;
    // this.L = 50;
    let dt = 1 / 60;
    let g = 1500;

    let bob = {
      phi: initPhi,
      v: 0,
      a: 0,
    };
    function drawPendulum() {
      ctx.beginPath();
      ctx.arc(Math.sin(bob.phi) * thisis.L, Math.cos(bob.phi) * thisis.L, 10, 0, 2 * Math.PI);
      ctx.fill();
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.sin(bob.phi) * thisis.L, Math.cos(bob.phi) * thisis.L);
      ctx.stroke();
    }
    function update() {
      bob.a = -(g / thisis.L) * Math.sin(bob.phi);
      bob.v += bob.a * dt;
      bob.phi += bob.v * dt;
    }
    
    function draw() {
      ctx.clearRect(-w / 2, -h / 2, w, h);
      drawPendulum();
      update();
      requestAnimationFrame(draw);
    }
    draw();
  },
};
</script>
<style lang="scss" scoped>
.canvas{
  border-top:2px solid black ;
}
</style>
