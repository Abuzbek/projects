<template>
  <v-app>
    <v-app-bar
      app
      color="#2a2a2a"
      dark
    >
     
    </v-app-bar>

    <v-main>
      <v-container fluid>
        <v-row>
          <v-col cols="12" md="6">
            <HelloWorld :L="L"/>
          </v-col>
          <v-col cols="12" md="6">
            <h3>{{'matematik mayatnik'.toUpperCase()}}</h3>
            <v-slider
              :max="400"
              :min="20"
              v-model="L"
            ></v-slider>
          </v-col>
        </v-row>
      </v-container>
    </v-main>
  </v-app>
</template>

<script>
import HelloWorld from './components/HelloWorld';

export default {
  name: 'App',
  data:()=>({
    L:200
  }),
  components: {
    HelloWorld,
  },
};
</script>
