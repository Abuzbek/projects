import React from "react";
import { useAlert } from "./alert/AlertContext";

export default function Main() {
  const { show } = useAlert();
  return (
    <div>
      <h1>Salom bu context</h1>
      <button
        onClick={() => show("Bu juda va juda muxim habar")}
        className="btn btn-success"
      >
        Alertni ko'ring
      </button>
    </div>
  );
}
