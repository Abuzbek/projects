import React, { useState,useMemo, useEffect } from "react";
import "./App.css";
function complesComputed(param) {
  console.log('complex computed...');
  let i = 0;
  while(i<1000000000) i++
  return param*2
}
function App() {
  const [number, setNumber] = useState(42);
  const [colored, setColored] = useState(false);
  const computed = useMemo(() => complesComputed(number), [number]);

  const styles=useMemo(()=>({
    color: colored ? 'blue' : 'black'
  }), [colored])
  useEffect(() => {
    console.log('styles changed');
  }, [styles])
  return (
    <>
      <h1 style={styles}>Number : {computed}</h1>
      <button
        className="btn btn-success"
        onClick={() => setNumber((e) => e + 1)}
      >
        +1
      </button>
      <button
        className="btn btn-danger"
        onClick={() => setNumber((e) => e - 1)}
      >
        -1
      </button>
      <button
        className="btn btn-danger"
        onClick={() => setColored((e) => !e)}
      >
        O'zgartir
      </button>
    </>
  );
}

export default App;
