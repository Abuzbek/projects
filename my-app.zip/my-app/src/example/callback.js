import React, { useState,useCallback } from "react";
import Items from '../Items'
import "./App.css";

function App() {
  const [number, setNumber] = useState(1);
  const [colored, setColored] = useState(false);

  const styles={
    color: colored ? 'blue' : 'black'
  }
  const generateItemFromAPI =useCallback(()=>{
    return new Array(number).fill('').map((_,i)=>`Elament: ${i+1}`)
  }, [number]) 
  // console.log(new Array(number).fill(''));
  return (
    <>
      <h1 style={styles}>Number : {number}</h1>
      <button
        className="btn btn-success"
        onClick={() => setNumber((e) => e + 1)}
      >
        +1
      </button>
      {/* <button
        className="btn btn-danger"
        onClick={() => setNumber((e) => e - 1)}
      >
        -1
      </button> */}
      <button
        className="btn btn-danger"
        onClick={() => setColored((e) => !e)}
      >
        O'zgartir
      </button>
      <Items getItems={generateItemFromAPI}/>
    </>
  );
}

export default App;
