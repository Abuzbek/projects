import React, { useState } from "react";
import "./App.css";
function counterFunc() {
  console.log("some colculating... ");
  return Math.trunc(Math.random() * 20);
}
function App() {
  const [counter, setCounter] = useState(() => {
    return counterFunc();
  });
  const [state, setState] = useState({
    title: "AbuzCoder",
    data: Date.now(),
  });
  function icrement() {
    setCounter((counter) => counter + 1);
  }
  function dicrement() {
    setCounter(counter - 1);
  }
  return (
    <div>
      <h1>{counter}</h1>
      <button onClick={icrement} className="btn btn-success">
        +1
      </button>
      <button onClick={dicrement} className="btn btn-danger">
        -1
      </button>
      <button
        onClick={() => setState({ ...state, title: "yangi ozgartirish" })}
        className="btn btn-primary"
      >
        O'zgartirish
      </button>
      <pre>{JSON.stringify(state, null, 2)}</pre>
    </div>
  );
}

export default App;
