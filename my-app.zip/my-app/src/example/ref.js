import React, { useEffect, useState, useRef } from "react";
import "./App.css";

function App() {
  const input = useRef(null);
  const prevValue = useRef('');
  const [state, setState] = useState("34");
  useEffect(() => {
    prevValue.current = state
  }, [state]);
  const focus = ()=> input.current.focus()
  return (
    <div>
      <h1>{prevValue.current}</h1>
      <input
        type="text"
        ref={input}
        onChange={(e) => setState(e.target.value)}
        value={state}
      ></input>
      <button onClick={focus}>{'click'}</button>
    </div>
  );
}

export default App;
