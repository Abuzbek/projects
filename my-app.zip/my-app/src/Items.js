import React, {useState,useEffect} from "react";

export default function Items({ getItems }) {
  const [state, setstate] = useState([])
  useEffect(()=>{
    console.log('render');
    const newIte = getItems()
    setstate(newIte)
  },[getItems])
  return <ul>{state.map((i)=><li key={i}>{i}</li>)}</ul>;
}
