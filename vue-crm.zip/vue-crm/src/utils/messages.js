export default {
  logout: 'Logout',
  login: 'FirstLogin',
  'auth/user-not-found': 'NoUserWithEmail',
  'auth/wrong-password': 'WrongPassword',
  'auth/email-already-in-use': 'EmailInUse'
}
